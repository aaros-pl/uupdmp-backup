UUP dump standalone
-------------------

### Description
This code is used by backend of UUP dump website to automatically retrieve new
builds and automatically generate packs used to create proper UUP sets.
